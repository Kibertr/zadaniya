<link rel="stylesheet" href="/css/css.css">
<div class="errors">
<?php
    echo $this->session->error;
    unset($this->session->error);
?>
</div>
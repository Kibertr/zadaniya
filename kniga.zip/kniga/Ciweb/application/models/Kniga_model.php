<?php
class Kniga_model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }
    function add_data($data){
        $text = $data['text'];
        $name = $data['name'];
        $date = date("Y-m-d H:i:s",time());
        $result = $this->db->query("INSERT INTO messages(`name`,`text`,`date`) VALUES('$name','$text','$date')");
        if($result){
            $_SESSION['error']= "сообщение успешно оставлено";
        }else{
            $_SESSION['error'] = "ошибка";
        }
        header("Location: kniga");
    }
    function get_messages(){
        $array= array();
        $result = $this->db->query("SELECT * FROM messages");
        foreach($result->result_array() as $val){
            $array[]=$val;
        }
        return $array;
    }
}
?>
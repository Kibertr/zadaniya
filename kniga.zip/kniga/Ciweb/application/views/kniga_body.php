<link rel="stylesheet" href="/css/css.css">
<link rel="stylesheet" href="/css/bootstrap.min.css">
<body>
<div class="row main">
    <?php
    foreach($data as $key=>$val){?>
        <div class="message_con col-md-3">
            <div class="info">
                <div class="name">
                    <?php
                    echo $val['name'];
                    ?>
                </div>
                <div class="date">
                    <?php
                    echo $val['date'];
                    ?>
                </div>
            </div> 
            <hr>
            <div class="text">
                <?php
                echo $val['text'];
                ?>
            </div>
        </div>
    <?php    
    }
    ?>
</div>
<body>

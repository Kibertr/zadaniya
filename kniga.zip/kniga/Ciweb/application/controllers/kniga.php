<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kniga extends CI_Controller {
	public function __construct(){
		parent::__construct();
        $this->load->model("Kniga_model");
	}
	public function index()
	{
		$this->load->view('kniga_head');
		if(!empty($_POST)){
			$error = $this->load->Kniga_model->add_data($_POST);
			if(isset($_SESSION['error'])){
				echo '<div style="margin:200px;">'.$_SESSION['error'].'</div>';
				unset($_SESSION['error']);
			}
		}
		$data['data'] = $this->load->Kniga_model->get_messages();
		if(!empty($data)){
			$this->load->view("kniga_body",$data);
		}
	}
}

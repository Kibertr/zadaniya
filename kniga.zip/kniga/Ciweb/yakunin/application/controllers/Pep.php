<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pep extends CI_Controller {
	public function index()
	{?>
<h1>helloy world<h1>
	<?php
    }
}

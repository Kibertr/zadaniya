<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/css.css">
<header>
    <form method="post" class="row">
        <div class="col-md-4">
            <input type="text" name="text" placeholder="сообщение" class="form-control">
        </div>
        <div class="col-md-4">
            <input type="text" name="name" placeholder="имя" class="form-control" >
        </div>
        <div class="col-md-2">
            <input type="submit" value="оставить сообщение" class="btn btn-primary">
        </div>
    </form>
</header>

